/**
 * @(#)ListQueue2.java
 *
 * Klasse ListQueue2<E> (ADS)
 * Queue als einfach verkettete Liste implementiert
 *
 * @author	Arnold Aders
 * @version 1.00 20130409
 */

public class ListQueue2<E> implements Queue<E> {
	private class ListElement {
		public E nd;	// NutzDaten
		public ListElement next;
		public ListElement(E nd, ListElement next) {
			this.nd = nd;
			this.next = next;
		}
	}
	private ListElement start;
	private int size=0;

	public int size() { return size;  }
	public boolean isEmpty() { return start==null; }

	public void put(E e) {
	//	vorne einf�gen:
		start = new ListElement(e,start);
		size++;
	}

	public E get() {
	//	hinten herausnehmen:
		if (start==null) return null;	// Queue war schon leer
		size--;
		if (start.next==null) {		// letztes Element herausnehmen
			E res = start.nd;
			start = null;
			return res;
		}
		// durchhangeln bis zum vorletzten:
		ListElement gf=start;
		while (gf.next.next!=null) gf = gf.next;
		E res = gf.next.nd;
		gf.next = null;
		return res;
	}
}
