/**
 * @(#)ListQueue.java
 *
 * Klasse ListQueue<E> (ADS)
 * Queue als einfach verkettete Liste implementiert
 *
 * @author Arnold Aders
 * @version 1.00 20130328
 */

public class ListQueue<E> implements Queue<E> {
	private int size=0;
	private ListElement begin;

	private class ListElement {
		public E nd;	// NutzDaten
		public ListElement next;
		public ListElement ( E nd ) {
			this.nd = nd;	// Nutzdaten
			next = null;
		}
	}

	public boolean isEmpty() { return size==0; }
	public int size() { return size; }

	public void put(E el) {
		if (begin==null) begin = new ListElement ( el );
		else {
			ListElement gf = begin;
			while (gf.next!=null) gf = gf.next;
			gf.next = new ListElement ( el );
		}
		size++;
	}

	public E get() {
		if (size==0) return null;
		E result=begin.nd;
		begin = begin.next;
		size--;
		return result;
	}
}
