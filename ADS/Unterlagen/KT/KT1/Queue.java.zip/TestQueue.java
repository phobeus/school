/**
 * @(#)TestQueue.java
 *
 * TestQueue testet die Klassen ListQueue<E> und ListQueue2<E>
 * ADS: Kurztest 1
 *
 * @author Arnold Aders
 * @version 1.00 20130409
 */

public class TestQueue {
	public static void main(String[] args) {
		final int N=3;
		Queue<String> queue = new ListQueue2<String>();
		for (int i=0; i<N; i++) {
			String s = "Hah"+(char)((int)'a'+i);
			queue.put(s);
			System.out.println("put(\""+s+"\"); "+queue.size()+" drin");
		}
		do System.out.println("get() -> \""+queue.get()+"\"; "
			+queue.size()+" drin");
		while (!queue.isEmpty());
		System.out.println("get() -> \""+queue.get()+"\"; "
			+queue.size()+" drin");
	}
}
