/**
 * @(#)Queue.java
 *
 * interface Queue<E> (ADS)
 *
 * @author Arnold Aders
 * @version 1.00 20130328
 */

public interface Queue<E> {
	public boolean isEmpty();
	public int size();
	public void put(E el);
	public E get();
}